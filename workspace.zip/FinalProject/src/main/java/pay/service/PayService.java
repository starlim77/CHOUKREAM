package pay.service;


public interface PayService {

	public int getOrderNumber();

	
}
