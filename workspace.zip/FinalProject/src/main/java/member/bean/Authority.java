package member.bean;

public enum Authority {
	ROLE_USER, ROLE_ADMIN
}
