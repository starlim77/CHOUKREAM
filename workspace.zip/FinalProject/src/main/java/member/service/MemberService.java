package member.service;

public interface MemberService {

}
